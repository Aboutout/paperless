$(document).ready(function() {
  setTimeout(function() {
    $('.wrapper').addClass('loaded');
    
  }, 3000);
});